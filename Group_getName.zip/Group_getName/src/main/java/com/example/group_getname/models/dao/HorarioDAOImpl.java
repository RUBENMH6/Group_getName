package com.example.group_getname.models.dao;

public class HorarioDAOImpl {
}
