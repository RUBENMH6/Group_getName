package com.example.group_getname.models.dao;

import com.example.group_getname.models.entity.Curso;

public interface CursoDAO {

    public void save(Curso curso);

}
