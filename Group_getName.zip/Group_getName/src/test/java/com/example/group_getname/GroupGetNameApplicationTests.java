package com.example.group_getname;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroupGetNameApplicationTests {

	@Test
	void contextLoads() {
	}

}
